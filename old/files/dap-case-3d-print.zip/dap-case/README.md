# Casing DAP ESP32 (layar 2.8") - 3D print

File: `dap_case.scad` (parametrik), `base.stl`, `top.stl`, `shelf.stl`, `btn.stl` (siap slice, orientasi cetak sudah benar), `section.png` (potongan penampang).

Untuk board Lolin D32 (57 x 25.4 mm, charger LiPo + micro-USB bawaan). Ukuran luar 104 x 64 x 28 mm. Tiga bagian:
- **base**: lantai + dinding bawah, ledge penyangga rak, 4 tiang baut, dudukan baterai.
- **shelf**: rak tipis di atas baterai, tempat D32 dan PCM5102A (cradle rusuk, dan celah kabel baterai di dekat micro-USB D32).
- **top**: bezel dengan jendela layar, bingkai posisi PCB layar, tiang baut.
- **btn**: 3 tutup tombol cetak (flensa di bed, plunger ke atas) untuk tact switch 6x6 mm yang dilem di rak di belakang lubang.

## Susunan (bawah ke atas)
lantai, baterai LiPo (~603450, kabel menuju JST D32), rak, D32 + PCM5102A, layar, bezel.

Lubang: micro-USB D32 (dinding kiri, flash + charge), jack 3.5 mm (kiri),
poros encoder 7.3 mm (dinding kanan, di garis sambungan, khusus volume), 3 lubang tombol PREV / NEXT / MENU 5.2 mm di dinding atas (X = 44, 56, 68), dan 1 lubang saklar power opsional (X = 84).

## Pengaturan cetak (saran)
- PETG atau PLA, layer 0.2 mm, 3 perimeter, infill 15-20%. Tanpa support.
- `top` dicetak menghadap bawah (bezel di bed). `base` dan `shelf` rata di bed.
- Cetak `top` dulu untuk uji pas layar (sekitar 20 cm3), baru cetak sisanya.

## Perakitan
1. Tempel layar ke bagian dalam bezel dengan double tape tipis di pinggir kaca. Bingkai di bezel mengunci posisi PCB.
2. Pasang baterai di base, lalu rak (kabel baterai lewat celah 3.5 mm di rak).
3. Taruh D32 dan PCM5102A di cradle rak, colok baterai ke JST D32 (cek polaritas); rekatkan dengan hot glue atau double tape. Encoder dilem di dekat lubang kanan.
4. Pasang 3 tutup tombol dari dalam (plunger ke luar), lalu dekatkan tact switch ke flensa (atur `btn_fl` bila kurang pas).
5. Tutup dengan 4 baut M2.5 x 20 dari bawah (self-tapping ke tiang di top).

## PENTING: ukur ulang sebelum cetak final
Semua ukuran komponen adalah perkiraan umum dan belum dicek ke komponenmu. Ukur dengan jangka sorong, lalu ubah di bagian atas `dap_case.scad`:
- `disp_pcb`, `disp_glass_h`, `active_size`, `active_off` (posisi area aktif di PCB; yang paling berpengaruh pada jendela)
- `batt`, `esp`, `pcm`, dan posisinya (`*_o`)
- `usb_micro_z`, `jack_z`, `enc_d`, `pwr_x` (opsional `use_usbc` bila memakai modul charger USB-C terpisah)

Render ulang: `openscad -D 'part="base"' -o base.stl dap_case.scad` (ganti base/top/shelf).
Bila modul layarmu punya lubang baut yang tidak bentrok dengan kaca, isi `disp_holes` dan set `use_disp_posts = true`.

## Catatan
- Lebih tebal dan lebar daripada DAP komersial. Untuk menipiskan: pakai baterai lebih tipis, solder kabel langsung tanpa header, atau buang rak.
- Belum dicetak dan dicoba. Mesh sudah dicek watertight dan susunan sudah dicek lewat potongan penampang.

## Catatan carrier board
Tombol atas disesuaikan untuk tact switch di carrier board (`btn_z = 14.6`). Lihat `carrierboard.zip`.
