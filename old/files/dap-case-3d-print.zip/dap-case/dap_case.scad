// ============================================================
//  Casing DAP ESP32 Lolin D32 (layar 2.8" ILI9341) - parametrik, 3 bagian
//  part = "base" | "top" | "shelf" | "btn" | "all"
//  Render: openscad -D 'part="base"' -o base.stl dap_case.scad
//  Sumbu: X = panjang, Y = lebar, Z = tebal (layar menghadap +Z)
//  SEMUA ukuran komponen di bawah adalah perkiraan umum. UKUR DENGAN JANGKA SORONG
//  lalu sesuaikan sebelum cetak final.
// ============================================================
part = "all";   // "base" | "top" | "shelf" | "btn" | "all"
$fn = 40;

// ---------- Layar 2.8" ILI9341 (modul SPI + slot SD) ----------
disp_pcb     = [86.0, 50.0, 1.6];   // PCB panjang x lebar x tebal
disp_glass_h = 2.9;                 // tebal kaca + backlight di atas PCB
active_size  = [57.6, 43.2];        // area tampilan aktif
active_off   = [22.6, 3.4];         // jarak area aktif dari pojok kiri-bawah PCB (sisi header di kiri)
win_margin   = 0.6;                 // jendela bezel lebih besar tiap sisi
disp_holes   = [];                  // contoh bila ada lubang baut: [[3,3],[83,3],[3,47],[83,47]]
use_disp_posts = false;             // true bila modul punya lubang baut dan tidak bentrok dengan kaca

// ---------- Komponen lain ----------
batt   = [51, 35, 7.5];             // LiPo ~603450 + ruang
esp    = [57, 25.4];                // Lolin D32 (57 x 25.4 mm, sumber: espboards.dev); header pin tidak dipakai, kabel disolder langsung
pcm    = [31.5, 17.5];              // modul PCM5102A
use_usbc = false;                   // true bila memakai modul charger USB-C terpisah (D32 sudah punya charger + micro-USB)
batt_o = [12, 14.5];                // posisi pojok kiri-bawah di lantai
esp_o  = [10, 6];                   // posisi di rak (shelf)
pcm_o  = [6, 38];

// ---------- Casing ----------
L = 104;  W = 64;  H = 28;
split   = 15;                       // tinggi sambungan base/top
wall    = 2.4;  floor_t = 2.0;  bezel = 2.6;  corner_r = 5;
shelf_z = 9.8;  shelf_t = 1.6;  ledge_w = 1.6;
tongue_h = 1.4;

// ---------- Lubang sisi ----------
usb_micro_z = 14.4;                 // sumbu konektor micro-USB ESP32
jack_z      = 16.0;                 // sumbu jack 3.5 mm
usbc_x      = 83.5;  usbc_z = 14.2; // USB-C modul IP5306 (dinding bawah)
enc_d       = 7.3;                  // poros rotary encoder (di garis sambungan)
pwr_x       = 84;   pwr_d = 5.2;    // lubang saklar power opsional (dinding atas)
btn_x       = [44, 56, 68];         // tombol atas PREV / NEXT / MENU (posisi X di dinding atas)
btn_d       = 5.2;                  // lubang tombol (plunger 4.8 mm)
btn_z       = 14.6;                 // tinggi sumbu tombol: tact switch di carrier board (atas PCB 11.4 + sekitar 3.2)
btn_fl      = 2.0;                  // tebal flensa tutup tombol (atur agar menyentuh tact switch)
btn_out     = 1.0;                  // tonjolan plunger di luar dinding

// ---------- Turunan ----------
dx = (L - disp_pcb.x) / 2;  dy = (W - disp_pcb.y) / 2;
zb = H - bezel;                     // permukaan dalam bezel
pcb_top = zb - disp_glass_h;  pcb_bot = pcb_top - disp_pcb.z;
pc = [[corner_r, corner_r], [L-corner_r, corner_r], [corner_r, W-corner_r], [L-corner_r, W-corner_r]];
post_r = 3.2;  screw_pilot = 2.1;  screw_thru = 2.7;

module rr2(l, w, r) { hull() for (x=[r, l-r], y=[r, w-r]) translate([x, y]) circle(r=r); }
module outline(inset=0, h=1) {
  translate([inset, inset, 0]) linear_extrude(h) rr2(L-2*inset, W-2*inset, max(corner_r-inset, 0.5));
}
module cavity(z0, h) { translate([wall, wall, z0]) linear_extrude(h) rr2(L-2*wall, W-2*wall, max(corner_r-wall, 0.5)); }

module corner_ribs(o, s, h, len=6, t=1.2) {
  for (cx=[0,1], cy=[0,1]) {
    xa = cx==0 ? o.x - t : o.x + s.x - len;  xb = cx==0 ? o.x + len : o.x + s.x + t;
    ya = cy==0 ? o.y - t : o.y + s.y;        yb = cy==0 ? o.y : o.y + s.y + t;
    translate([xa, ya, 0]) cube([xb-xa, yb-ya, h]);
    xa2 = cx==0 ? o.x - t : o.x + s.x;       xb2 = cx==0 ? o.x : o.x + s.x + t;
    ya2 = cy==0 ? o.y - t : o.y + s.y - len; yb2 = cy==0 ? o.y + len : o.y + s.y + t;
    translate([xa2, ya2, 0]) cube([xb2-xa2, yb2-ya2, h]);
  }
}

module side_cutouts() {
  translate([-1, esp_o.y + esp.y/2 - 4.7, usb_micro_z - 2.1]) cube([wall+2, 9.4, 4.2]);          // micro-USB (flash)
  translate([-1, pcm_o.y + pcm.y/2, jack_z]) rotate([0,90,0]) cylinder(d=6.6, h=wall+2);        // jack 3.5 mm
  if (use_usbc) translate([usbc_x - 4.7, -1, usbc_z - 1.8]) cube([9.4, wall+2, 3.6]);          // USB-C (opsional)
  translate([L-wall-1, W/2, split]) rotate([0,90,0]) cylinder(d=enc_d, h=wall+2);               // encoder
  translate([pwr_x, W-wall-1, split]) rotate([-90,0,0]) cylinder(d=pwr_d, h=wall+2);            // saklar power
  for (bx = btn_x) translate([bx, W-wall-1, btn_z]) rotate([-90,0,0]) cylinder(d=btn_d, h=wall+2); // tombol atas
}

// ======================= BASE =======================
module base() {
  difference() {
    union() {
      difference() { outline(0, split); cavity(floor_t, split); }
      translate([0,0,floor_t-0.01]) linear_extrude(shelf_z-floor_t+0.01)             // ledge penyangga rak
        difference() { translate([wall, wall]) rr2(L-2*wall, W-2*wall, max(corner_r-wall,0.5));
                       translate([wall+ledge_w, wall+ledge_w]) rr2(L-2*(wall+ledge_w), W-2*(wall+ledge_w), 1); }
      translate([0,0,split-0.01]) linear_extrude(tongue_h+0.01)                      // lidah sambungan
        difference() { translate([wall/2, wall/2]) rr2(L-wall, W-wall, max(corner_r-wall/2,0.5));
                       translate([wall, wall]) rr2(L-2*wall, W-2*wall, max(corner_r-wall,0.5)); }
      for (p = pc) translate([p.x, p.y, floor_t-0.01]) cylinder(r=post_r, h=split-floor_t+0.01);   // tiang baut
      translate([0,0,floor_t-0.01]) corner_ribs(batt_o, [batt.x, batt.y], 4);                      // dudukan baterai
    }
    for (p = pc) {
      translate([p.x, p.y, -1]) cylinder(d=screw_thru, h=split+2);
      translate([p.x, p.y, -0.01]) cylinder(d1=5.4, d2=screw_thru, h=1.5);                         // countersink
    }
    side_cutouts();
  }
}

// ======================= TOP (bezel) =======================
module top_shell() {
  difference() {
    union() {
      difference() {
        hull() { translate([0,0,split]) outline(0, H-split-1.2); translate([0,0,H-1.2]) outline(1.2, 1.2); }
        cavity(split-0.01, zb-split+0.01);
      }
      for (p = pc) translate([p.x, p.y, split]) cylinder(r=post_r-0.2, h=zb-split+0.01);          // tiang baut
      translate([0,0,pcb_bot]) linear_extrude(zb-pcb_bot+0.01) difference() {                       // bingkai posisi layar
        translate([dx-1.4, dy-1.4]) square([disp_pcb.x+2.8, disp_pcb.y+2.8]);
        translate([dx-0.2, dy-0.2]) square([disp_pcb.x+0.4, disp_pcb.y+0.4]);
      }
      if (use_disp_posts) for (h = disp_holes) translate([dx+h.x, dy+h.y, pcb_top]) cylinder(d=5, h=zb-pcb_top+0.01);
    }
    // jendela layar + chamfer luar
    translate([dx+active_off.x-win_margin, dy+active_off.y-win_margin, zb-0.01]) linear_extrude(bezel+0.02)
      rr2(active_size.x+2*win_margin, active_size.y+2*win_margin, 1.5);
    hull() {
      translate([dx+active_off.x-win_margin, dy+active_off.y-win_margin, H-0.8]) linear_extrude(0.01)
        rr2(active_size.x+2*win_margin, active_size.y+2*win_margin, 1.5);
      translate([dx+active_off.x-win_margin-0.8, dy+active_off.y-win_margin-0.8, H]) linear_extrude(0.01)
        rr2(active_size.x+2*win_margin+1.6, active_size.y+2*win_margin+1.6, 2.3);
    }
    translate([0,0,split-0.01]) linear_extrude(tongue_h+0.3) difference() {                         // alur lidah
      translate([wall/2-0.15, wall/2-0.15]) rr2(L-wall+0.3, W-wall+0.3, max(corner_r-wall/2+0.15,0.5));
      translate([wall+0.15, wall+0.15]) rr2(L-2*wall-0.3, W-2*wall-0.3, max(corner_r-wall-0.15,0.5));
    }
    for (p = pc) translate([p.x, p.y, split-0.01]) cylinder(d=screw_pilot, h=9);                     // lubang pilot baut
    if (use_disp_posts) for (h = disp_holes) translate([dx+h.x, dy+h.y, pcb_top-0.01]) cylinder(d=screw_pilot, h=zb-pcb_top+1.2);
    side_cutouts();
  }
}

// ======================= SHELF (rak elektronik) =======================
module shelf() {
  translate([0,0,shelf_z]) {
    difference() {
      linear_extrude(shelf_t) difference() {
        translate([wall+0.2, wall+0.2]) rr2(L-2*(wall+0.2), W-2*(wall+0.2), max(corner_r-wall-0.2,0.5));
        for (p = pc) translate(p) circle(r=post_r+0.3);
        translate([4.6, 6]) square([3.8, 26]);                                                       // jalur kabel baterai ke JST D32 (dekat micro-USB)
      }
    }
    translate([0,0,shelf_t-0.01]) {
      corner_ribs([esp_o.x-0.2, esp_o.y-0.2], [esp.x+0.4, esp.y+0.4], 2.2);
      corner_ribs([pcm_o.x-0.2, pcm_o.y-0.2], [pcm.x+0.4, pcm.y+0.4], 2.2, 5);
    }
  }
}

// Tutup tombol (dicetak flensa di bed, plunger ke atas). Tact switch 6x6 dilem di rak tepat di belakang lubang.
module btn_cap() {
  cylinder(d=6.4, h=btn_fl);
  cylinder(d=btn_d-0.4, h=btn_fl+wall+btn_out);
}

if (part == "base") base();
else if (part == "btn") for (i = [0:2]) translate([i*10, 0, 0]) btn_cap();
else if (part == "top") translate([0, W, H]) rotate([180,0,0]) top_shell();      // posisi cetak: bezel di bed
else if (part == "shelf") translate([0,0,-shelf_z]) shelf();
else if (part == "all") { color("#444") base(); color("#38bdf8") shelf(); color("#222") translate([0,0,0.001]) top_shell(); }
