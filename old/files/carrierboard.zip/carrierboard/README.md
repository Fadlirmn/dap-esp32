# Carrier board DAP ESP32 (Lolin D32)

Isi paket:
- `carrierboard-netlist.xlsx`: netlist (20 net), pemetaan 32 pin D32, pemetaan konektor, BOM, aturan PCB.
- `outline.dxf`: outline papan 98.8 x 58.8 mm (layer EDGE_CUTS), keep-out antena, kotak modul, posisi tact switch. Satuan mm, asal di pojok kiri-bawah. Busur didekati dengan segmen garis.
- `placement.png`: gambar penempatan skala 1:1.

## Ide
PCB ini menggantikan rak cetak (`shelf`): ukuran dan takik pojok mengikuti rak, jadi duduk di ledge yang sama (z 9.8 sampai 11.4). Di atasnya dipasang D32, PCM5102A, 3 tact switch (PREV, NEXT, MENU), resistor pull-up, dan kapasitor. Kabel tersisa hanya untuk layar (14 + 4 kawat), encoder (5 kawat), dan baterai ke JST D32.

## Hal yang harus diverifikasi sebelum memesan PCB
1. **Urutan pin modul layar dan DAC.** Urutan di netlist adalah urutan umum; cocokkan dengan silkscreen modulmu.
2. **Footprint D32**: 2 baris x 16 pin, pitch 2.54 mm (dari espboards.dev). Jarak antar baris belum saya verifikasi (perkiraan 22.86 mm). Ukur dengan jangka sorong atau pakai gambar board skala dari espboards.dev sebagai acuan.
3. **Posisi konektor J_LCD, J_SD, J_ENC** hanya saran. Header layar biasanya ada di ujung kiri layar, sedangkan konektor disarankan di sisi kanan papan, jadi kabel ke layar cukup panjang. Pilihan lain: pindahkan konektor, atau putar layar 180 derajat (perlu perubahan casing dan `setRotation`).
4. **Tinggi D32**: solder rendah (standoff sekitar 1 mm). Dengan header berplastik, naikkan `H` di `dap_case.scad` ke sekitar 30 mm lalu render ulang `top`.
5. **Jumper J1 modul layar** (bila ada) mungkin perlu ditutup saat VCC 3.3 V.
6. **Keep-out antena** di `outline.dxf` adalah perkiraan; sesuaikan dengan antena D32 sungguhan.

7. **SDO layar (J_LCD pin 9) dibiarkan tidak tersambung.** Firmware tidak membaca dari layar, dan T_DO (touch) serta MISO kartu SD sudah memakai GPIO 19. Dengan begitu tidak ada dua output di satu jalur.

## Tombol dan casing
Tact switch menghadap dinding atas casing, pusat X (PCB) 41.4, 53.4, 65.4 dan Y 53.0. Casing sudah disesuaikan (`btn_z = 14.6`, bagian `top`, `base`, dan `btn` dirender ulang).

## Alur
1. Buat skematik di KiCad atau EasyEDA dari netlist.
2. Impor `outline.dxf` sebagai Edge.Cuts, lalu letakkan footprint.
3. Cetak 1:1 di kertas untuk uji pas, baru pesan.
